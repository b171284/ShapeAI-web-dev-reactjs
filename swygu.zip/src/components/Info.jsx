import React from "react";
function Info(){
  return(
    <div className="note">
      <h1>7 DAY LONG FREE PYTHON 
        AND NATURAL LANGUAGE PROCESSING
         BOOTCAMP
      </h1>
      <p>*starts 27th june...
        *certificates........
        *hands on projects...
      </p>
      </div>
);
}
export default Info;