import React from "react";
function Info1(){
  return(
    <div className="note">
      <h1>7 DAY LONG FREE PYTHON 
        AND NETWORK SECURITY
         BOOTCAMP
      </h1>
      <p>
        *starts 27th june...
        *certificates........
        *hands on projects...
        *no prerequisites
        </p>
      </div>
);
}
export default Info1;